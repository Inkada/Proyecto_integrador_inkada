import java.util.Iterator;
import java.util.LinkedList;
import java.util.TreeSet;

import processing.core.PApplet;

public class Logica {
	/* Inicializacion de listas y app */
	private PApplet app = MainApp.app;
	private LinkedList<Atributo> atributos;
	private TreeSet<Atributo> apellido;

	public Logica() {
		atributos = new LinkedList<>();
		apellido = new TreeSet<>();

	}

	/* se cargan los archivos .txt */
	public void cargarTxt() {

		String[] Color = app.loadStrings("../Data/Colores");
		String[] Dato = app.loadStrings("../Data/Datos");
		String[] Nombre = app.loadStrings("../Data/Nombres");

		for (int i = 0; i < Color.length; i++) {
			String[] Nombres = Nombre[i].split(":");
			String[] Datos = Dato[i].split("/");
			String[] Colores = Color[i].split("/");

			app.println(Nombres);
			app.println(Datos);
			app.println(Colores);

			float[] NombreFloat = new float[Nombre.length];
			for (int j = 0; j < Nombres.length; j++) {
				NombreFloat[j] = Float.parseFloat(Nombres[j]);
			}

			float[] ColorFloat = new float[Colores.length];
			for (int j = 0; j < Colores.length; j++) {
				ColorFloat[j] = Float.parseFloat(Colores[j]);
			}

			float[] DatoFloat = new float[Datos.length];
			for (int j = 0; j < Datos.length; j++) {
				DatoFloat[j] = Float.parseFloat(Datos[j]);
			}
		}
	}

	public void Pintar() {

		Iterator<Atributo> T = atributos.iterator();
		int i = 0;
		while (T.hasNext()) {
			Atributo N = T.next();
			N.pintar(40 + 40 * i);
			i++;
		}

	}

	public void Ordenar() {
		if (app.key == '1') {

		}
		if (app.key == '2') {

		}
		if (app.key == '4') {

		}
	}
}
