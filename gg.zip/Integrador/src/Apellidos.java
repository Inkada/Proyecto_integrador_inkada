import java.util.Comparator;

public class Apellidos implements Comparator<Atributo> {

	public int compare(Atributo i1, Atributo i2) {
		return i1.getApellido().compareTo(i2.getApellido());
	}
}
