import java.util.Comparator;

public class Colores implements Comparator<Atributo> {

	public int compare(Atributo i1, Atributo i2) {
		return (int) (i1.getC() - i2.getC());

	}
}