import processing.core.PApplet;

public class MainApp extends PApplet {

	public static PApplet app;
	Logica log;

	public static void main(String[] args) {
		PApplet.main("MainApp");

	}

	public void settings() {
		size(900, 600);

	}

	public void setup() {
		log = new Logica();

	}

	public void draw() {
		background(0);
	}

	public void keyPressed() {

	}

}
